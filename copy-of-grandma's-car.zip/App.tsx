
import React, { useState, useCallback, useEffect } from 'react';
import { cars as mockCars, mechanics as mockMechanics, Car, Mechanic } from './data';
import { 
    SparklesIcon, 
    ShieldCheckIcon, 
    WrenchScrewdriverIcon, 
    StarIcon, 
    MapPinIcon,
    ChatBubbleLeftRightIcon
} from './components/icons';
import { findCarsByNaturalLanguage, getMaintenanceForecast } from './services/geminiService';

// TYPES
export type Page = 'home' | 'listing' | 'mechanics' | 'about' | 'sell';


// HEADER COMPONENT
const Header: React.FC<{ onNavigate: (page: Page) => void; onLogoClick: () => void }> = ({ onNavigate, onLogoClick }) => {
    return (
        <header className="bg-white/80 backdrop-blur-lg shadow-sm sticky top-0 z-50">
            <nav className="container mx-auto px-6 py-4 flex justify-between items-center">
                <button onClick={onLogoClick} className="text-2xl font-bold text-gray-800">
                    Grandma's Car 👵
                </button>
                <div className="hidden md:flex items-center space-x-8">
                    <button onClick={() => onNavigate('home')} className="text-gray-600 hover:text-blue-600 transition">Shop Cars</button>
                    <button onClick={() => onNavigate('sell')} className="text-gray-600 hover:text-blue-600 transition">Sell Your Car</button>
                    <button onClick={() => onNavigate('mechanics')} className="text-gray-600 hover:text-blue-600 transition">Mechanics</button>
                    <button onClick={() => onNavigate('about')} className="text-gray-600 hover:text-blue-600 transition">About Us</button>
                </div>
                <button onClick={() => onNavigate('sell')} className="hidden md:block bg-gradient-to-r from-orange-500 to-pink-500 text-white font-semibold px-5 py-2 rounded-lg shadow-md hover:scale-105 transition-transform">
                    Sell Your Car
                </button>
            </nav>
        </header>
    );
};

// FOOTER COMPONENT
const Footer: React.FC<{ onNavigate: (page: Page) => void }> = ({ onNavigate }) => {
    return (
        <footer className="bg-gray-800 text-white">
            <div className="container mx-auto px-6 py-12">
                <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
                    <div>
                        <h3 className="text-xl font-bold mb-4">Grandma's Car 👵</h3>
                        <p className="text-gray-400">Find your next car the Grandma-approved way.</p>
                    </div>
                    <div>
                        <h4 className="font-semibold mb-4">Quick Links</h4>
                        <ul>
                            <li className="mb-2"><button onClick={() => onNavigate('home')} className="hover:text-blue-400">Shop Cars</button></li>
                            <li className="mb-2"><button onClick={() => onNavigate('sell')} className="hover:text-blue-400">Sell Your Car</button></li>
                            <li className="mb-2"><button onClick={() => onNavigate('mechanics')} className="hover:text-blue-400">Verified Mechanics</button></li>
                            <li className="mb-2"><button onClick={() => onNavigate('about')} className="hover:text-blue-400">About Us</button></li>
                        </ul>
                    </div>
                    <div>
                        <h4 className="font-semibold mb-4">Trust & Safety</h4>
                        <div className="flex space-x-4">
                            <ShieldCheckIcon className="w-8 h-8 text-green-400" />
                            <WrenchScrewdriverIcon className="w-8 h-8 text-blue-400" />
                        </div>
                    </div>
                    <div>
                        <h4 className="font-semibold mb-4">Contact Us</h4>
                        <p className="text-gray-400">support@grandmascar.com</p>
                    </div>
                </div>
                <div className="mt-12 border-t border-gray-700 pt-6 text-center text-gray-500 text-sm">
                    &copy; {new Date().getFullYear()} Grandma's Car. All Rights Reserved.
                </div>
            </div>
        </footer>
    );
};


// CAR CARD COMPONENT
const CarCard: React.FC<{ car: Car; onView: (car: Car) => void }> = ({ car, onView }) => {
    return (
        <div className="bg-white rounded-xl shadow-lg overflow-hidden transform hover:-translate-y-2 transition-transform duration-300">
            <img className="w-full h-56 object-cover" src={car.imageUrl} alt={car.name} />
            <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-800">{car.name}</h3>
                <p className="text-gray-600 mt-1">{car.year} &bull; {car.mileage.toLocaleString()} miles</p>
                <div className="mt-4 flex justify-between items-center">
                    <p className="text-3xl font-extrabold text-blue-600">${car.price.toLocaleString()}</p>
                    <div className="text-right">
                         <div className="flex items-center justify-end text-sm text-gray-500">
                            <ShieldCheckIcon className="w-5 h-5 text-green-500 mr-1" />
                            Reliability: {car.reliabilityScore}/100
                        </div>
                         <div className="flex items-center justify-end text-sm text-gray-500 mt-1">
                             <WrenchScrewdriverIcon className="w-5 h-5 text-blue-500 mr-1" />
                            Mechanic Rated
                        </div>
                    </div>
                </div>
                <button onClick={() => onView(car)} className="mt-6 w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold py-3 rounded-lg shadow-md hover:scale-105 transition-transform">
                    View Details
                </button>
            </div>
        </div>
    );
};


// AI CHATBOT COMPONENT
const AiChatbot: React.FC = () => {
    const [isOpen, setIsOpen] = useState(false);
    
    return (
        <div className="fixed bottom-8 right-8 z-50">
            {isOpen && (
                 <div className="bg-white w-80 h-96 rounded-xl shadow-2xl flex flex-col">
                    <div className="p-4 bg-gradient-to-r from-blue-500 to-purple-600 rounded-t-xl text-white">
                        <h3 className="font-bold">AI Buyer Assistant</h3>
                        <p className="text-sm opacity-90">Ask me anything!</p>
                    </div>
                    <div className="flex-grow p-4 text-sm text-gray-500">
                        Ask about cars, financing, or the inspection process.
                    </div>
                     <div className="p-2 border-t">
                         <input type="text" placeholder="Type your question..." className="w-full border-gray-300 rounded-md p-2 text-sm" />
                    </div>
                </div>
            )}
            <button onClick={() => setIsOpen(!isOpen)} className="mt-4 bg-gradient-to-r from-pink-500 to-orange-500 text-white rounded-full p-4 shadow-lg hover:scale-110 transition-transform">
                 <ChatBubbleLeftRightIcon className="w-8 h-8" />
            </button>
        </div>
    );
};

// HOME PAGE VIEW
const HomePage: React.FC<{ onViewCar: (car: Car) => void; onNavigate: (page: Page) => void }> = ({ onViewCar }) => {
    const [searchQuery, setSearchQuery] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [filteredCars, setFilteredCars] = useState(mockCars);

    const handleSearch = async (e: React.FormEvent) => {
        e.preventDefault();
        setIsLoading(true);
        const results = await findCarsByNaturalLanguage(searchQuery);
        setFilteredCars(results);
        setIsLoading(false);
    };
    
    return (
        <div>
            {/* Hero Section */}
            <section 
                className="relative bg-cover bg-center py-24 text-center"
                style={{ backgroundImage: "url('https://images.pexels.com/photos/4480505/pexels-photo-4480505.jpeg')" }}
            >
                <div className="absolute inset-0 bg-black/60 backdrop-blur-sm"></div>
                <div className="relative container mx-auto px-6">
                    <h1 className="text-5xl md:text-6xl font-extrabold text-white">Good Cars. Honest Sellers.</h1>
                    <h2 className="text-5xl md:text-6xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-purple-400 to-pink-400">Mechanic Approved.</h2>
                    <p className="mt-4 text-lg text-gray-200 max-w-2xl mx-auto">The simple, transparent, and enjoyable way to buy a reliable used car.</p>
                    
                    {/* AI Car Finder */}
                    <form onSubmit={handleSearch} className="mt-8 max-w-2xl mx-auto">
                        <div className="relative">
                            <SparklesIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-6 h-6 text-purple-400" />
                            <input
                                type="text"
                                value={searchQuery}
                                onChange={(e) => setSearchQuery(e.target.value)}
                                placeholder="e.g., 'I need a safe SUV under $15k for my family'"
                                className="w-full pl-12 pr-32 py-4 text-lg text-gray-900 border-2 border-transparent rounded-full focus:ring-purple-500 focus:border-purple-500 transition shadow-lg"
                            />
                            <button type="submit" className="absolute right-2 top-1/2 -translate-y-1/2 bg-gradient-to-r from-blue-500 to-purple-600 text-white font-semibold px-6 py-2.5 rounded-full hover:scale-105 transition-transform">
                                {isLoading ? 'Searching...' : 'Find My Car'}
                            </button>
                        </div>
                    </form>
                </div>
            </section>

            {/* Featured Cars */}
            <section className="py-16">
                <div className="container mx-auto px-6">
                    <h2 className="text-4xl font-bold text-center mb-12">Featured Cars</h2>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
                        {filteredCars.map(car => <CarCard key={car.id} car={car} onView={onViewCar} />)}
                    </div>
                </div>
            </section>
        </div>
    );
};

// LISTING PAGE VIEW
const ListingPage: React.FC<{ car: Car; onBack: () => void }> = ({ car, onBack }) => {
    const [forecast, setForecast] = useState<string[]>([]);

    useEffect(() => {
        const fetchForecast = async () => {
            const result = await getMaintenanceForecast(car);
            setForecast(result);
        }
        fetchForecast();
    }, [car]);

    return (
        <div className="container mx-auto px-6 py-12">
            <button onClick={onBack} className="mb-8 text-blue-600 hover:underline">
                &larr; Back to Listings
            </button>
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
                <div className="lg:col-span-2">
                    <img src={car.imageUrl} alt={car.name} className="w-full h-auto rounded-2xl shadow-lg" />
                    {/* AI Maintenance Predictor */}
                    <div className="mt-8 bg-white p-6 rounded-xl shadow-md border">
                         <h3 className="text-2xl font-bold text-gray-800 flex items-center"><SparklesIcon className="w-6 h-6 text-purple-500 mr-2" /> Smart Maintenance Forecast</h3>
                        <ul className="mt-4 list-disc list-inside text-gray-600 space-y-2">
                            {forecast.map((item, index) => <li key={index}>{item}</li>)}
                        </ul>
                    </div>
                </div>
                <div>
                    <div className="bg-white p-8 rounded-2xl shadow-lg sticky top-28">
                        <h1 className="text-4xl font-extrabold text-gray-900">{car.name}</h1>
                        <p className="text-gray-600 mt-2 text-lg">{car.year} &bull; {car.mileage.toLocaleString()} miles</p>
                        <p className="text-5xl font-bold text-blue-600 my-6">${car.price.toLocaleString()}</p>
                        <div className="space-y-4 text-gray-700">
                             <div className="flex items-center"><ShieldCheckIcon className="w-6 h-6 text-green-500 mr-3" /> <span>Reliability Score: <span className="font-bold">{car.reliabilityScore}/100</span></span></div>
                             <div className="flex items-center"><WrenchScrewdriverIcon className="w-6 h-6 text-blue-500 mr-3" /> <span>Inspected by <span className="font-bold">{car.inspection.mechanicName}</span></span></div>
                        </div>
                         <button className="mt-8 w-full bg-gradient-to-r from-orange-500 to-pink-500 text-white font-bold py-4 rounded-xl shadow-lg hover:scale-105 transition-transform text-lg">
                            Make an Offer
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

// MECHANICS PAGE VIEW
const MechanicsPage: React.FC = () => {
    return (
        <div className="container mx-auto px-6 py-16">
            <h1 className="text-4xl font-bold text-center mb-12">Verified Mechanics</h1>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {mockMechanics.map(mechanic => (
                    <div key={mechanic.id} className="bg-white p-6 rounded-xl shadow-lg border">
                        <h2 className="text-2xl font-bold text-gray-800">{mechanic.name}</h2>
                        <p className="text-gray-600 flex items-center mt-2"><MapPinIcon className="w-5 h-5 mr-2 text-gray-400" /> {mechanic.location}</p>
                        <div className="flex items-center mt-4">
                            {[...Array(5)].map((_, i) => <StarIcon key={i} solid={i < mechanic.rating} className="w-6 h-6 text-yellow-400" />)}
                            <span className="ml-2 text-gray-600">{mechanic.rating.toFixed(1)}</span>
                        </div>
                        <p className="mt-4 text-sm text-gray-500">{mechanic.specialty}</p>
                    </div>
                ))}
            </div>
        </div>
    );
};

// ABOUT PAGE VIEW
const AboutPage: React.FC = () => (
    <div className="bg-gray-100 py-20">
        <div className="container mx-auto px-6 text-center max-w-3xl">
            <h1 className="text-5xl font-extrabold text-gray-800">Built to make car buying less stressful and more human.</h1>
            <p className="mt-6 text-lg text-gray-600">
                At Grandma's Car, we believe buying a used car shouldn't be a gamble. We got tired of the confusing listings, hidden problems, and pushy salespeople. So we built something better: a marketplace founded on trust, transparency, and the simple idea that everyone deserves a reliable car.
            </p>
            <div className="mt-12 p-8 bg-white rounded-xl shadow-lg border">
                <h2 className="text-3xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-blue-500 to-green-500">Our Mission</h2>
                <p className="mt-4 text-xl text-gray-700">Every car inspected. Every buyer protected.</p>
            </div>
        </div>
    </div>
);


// SELL PAGE VIEW
const SellPage: React.FC = () => (
     <div className="container mx-auto px-6 py-20 max-w-4xl">
        <h1 className="text-5xl font-extrabold text-center text-gray-800">Sell Your Car, The Simple Way</h1>
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="bg-white p-8 rounded-xl shadow-lg border">
                <div className="text-4xl font-bold text-blue-500 mb-4">1</div>
                <h3 className="text-2xl font-bold mb-2">Get Inspected</h3>
                <p className="text-gray-600">Choose one of our verified local mechanics to perform a standardized inspection.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg border">
                <div className="text-4xl font-bold text-purple-500 mb-4">2</div>
                <h3 className="text-2xl font-bold mb-2">Upload Details</h3>
                <p className="text-gray-600">We'll help you upload photos, the inspection report, and your service history.</p>
            </div>
            <div className="bg-white p-8 rounded-xl shadow-lg border">
                <div className="text-4xl font-bold text-pink-500 mb-4">3</div>
                <h3 className="text-2xl font-bold mb-2">Get Listed</h3>
                <p className="text-gray-600">Your car goes live! We handle the questions and connect you with serious buyers.</p>
            </div>
        </div>
         <p className="text-center mt-8 text-gray-500">*Note: All cars must have a clean title and a completed inspection to be listed.</p>
    </div>
);


// MAIN APP COMPONENT
const App: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedCar, setSelectedCar] = useState<Car | null>(null);

  const navigate = useCallback((page: Page) => {
    setCurrentPage(page);
    window.scrollTo(0, 0);
  }, []);

  const viewCar = useCallback((car: Car) => {
    setSelectedCar(car);
    navigate('listing');
  }, [navigate]);

  const goHome = useCallback(() => {
    setSelectedCar(null);
    navigate('home');
  }, [navigate]);

  const renderPage = () => {
    switch (currentPage) {
      case 'listing':
        return selectedCar ? <ListingPage car={selectedCar} onBack={goHome} /> : <HomePage onViewCar={viewCar} onNavigate={navigate} />;
      case 'mechanics':
        return <MechanicsPage />;
      case 'about':
        return <AboutPage />;
      case 'sell':
        return <SellPage />;
      case 'home':
      default:
        return <HomePage onViewCar={viewCar} onNavigate={navigate} />;
    }
  };

  return (
    <div className="bg-gray-50 min-h-screen text-gray-800 font-sans flex flex-col">
      <Header onNavigate={navigate} onLogoClick={goHome} />
      <main className="flex-grow">
        {renderPage()}
      </main>
      <AiChatbot />
      <Footer onNavigate={navigate} />
    </div>
  );
};

export default App;
