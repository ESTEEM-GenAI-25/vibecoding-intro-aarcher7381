// DATA AND TYPES

export interface Mechanic {
    id: number;
    name: string;
    location: string;
    rating: number;
    specialty: string;
}

export interface InspectionReport {
    mechanicName: string;
    passedItems: number;
    totalItems: number;
    notes: string;
}

export interface Car {
    id: number;
    name: string;
    make: string;
    year: number;
    price: number;
    mileage: number;
    type: 'Sedan' | 'SUV' | 'Truck' | 'Hatchback';
    imageUrl: string;
    reliabilityScore: number;
    inspection: InspectionReport;
}

export const mechanics: Mechanic[] = [
    { id: 1, name: 'Honest Abe\'s Auto', location: 'Springfield, USA', rating: 4.8, specialty: 'Specializes in Japanese Imports' },
    { id: 2, name: 'Trusty Tune-Ups', location: 'Metro City, USA', rating: 4.9, specialty: 'European & Luxury Vehicle Experts' },
    { id: 3, name: 'Reliable Rides Repair', location: 'Oakwood, USA', rating: 4.7, specialty: 'General Automotive & Domestic Cars' },
];

export const cars: Car[] = [
    {
        id: 1,
        name: 'Honda Civic LX',
        make: 'Honda',
        year: 2019,
        price: 18500,
        mileage: 45000,
        type: 'Sedan',
        imageUrl: 'https://images.pexels.com/photos/6794811/pexels-photo-6794811.jpeg',
        reliabilityScore: 95,
        inspection: {
            mechanicName: 'Honest Abe\'s Auto',
            passedItems: 148,
            totalItems: 150,
            notes: 'Minor scuff on rear bumper. Tires are at 70% tread.',
        },
    },
    {
        id: 2,
        name: 'Toyota RAV4 XLE',
        make: 'Toyota',
        year: 2020,
        price: 26000,
        mileage: 32000,
        type: 'SUV',
        imageUrl: 'https://images.pexels.com/photos/9615358/pexels-photo-9615358.jpeg',
        reliabilityScore: 98,
        inspection: {
            mechanicName: 'Trusty Tune-Ups',
            passedItems: 150,
            totalItems: 150,
            notes: 'Excellent condition. All service records up to date.',
        },
    },
    {
        id: 3,
        name: 'Ford F-150 Lariat',
        make: 'Ford',
        year: 2018,
        price: 32000,
        mileage: 68000,
        type: 'Truck',
        imageUrl: 'https://images.pexels.com/photos/33336584/pexels-photo-33336584.jpeg',
        reliabilityScore: 88,
        inspection: {
            mechanicName: 'Reliable Rides Repair',
            passedItems: 145,
            totalItems: 150,
            notes: 'New brake pads installed. Small dent on tailgate.',
        },
    },
     {
        id: 4,
        name: 'Subaru Outback',
        make: 'Subaru',
        year: 2021,
        price: 27500,
        mileage: 25000,
        type: 'SUV',
        imageUrl: 'https://images.pexels.com/photos/15928393/pexels-photo-15928393.jpeg',
        reliabilityScore: 92,
        inspection: {
            mechanicName: 'Honest Abe\'s Auto',
            passedItems: 149,
            totalItems: 150,
            notes: 'Pristine interior. AWD system checks out perfectly.',
        },
    },
     {
        id: 5,
        name: 'Volkswagen Golf',
        make: 'Volkswagen',
        year: 2017,
        price: 14000,
        mileage: 55000,
        type: 'Hatchback',
        imageUrl: 'https://images.pexels.com/photos/28447293/pexels-photo-28447293.jpeg',
        reliabilityScore: 85,
        inspection: {
            mechanicName: 'Trusty Tune-Ups',
            passedItems: 147,
            totalItems: 150,
            notes: 'Fun to drive. Clutch feels solid.',
        },
    },
     {
        id: 6,
        name: 'Hyundai Sonata',
        make: 'Hyundai',
        year: 2020,
        price: 21000,
        mileage: 38000,
        type: 'Sedan',
        imageUrl: 'https://images.pexels.com/photos/33751549/pexels-photo-33751549.jpeg',
        reliabilityScore: 93,
        inspection: {
            mechanicName: 'Reliable Rides Repair',
            passedItems: 150,
            totalItems: 150,
            notes: 'Like new. Still has that new car smell.',
        },
    },
];