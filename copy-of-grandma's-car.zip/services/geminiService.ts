import { Car, cars } from '../data';

// Mock AI Service to simulate Gemini API calls

/**
 * Simulates an AI-powered search that understands natural language.
 * @param query - A natural language query like "a safe car under $15k for a family"
 * @returns A promise that resolves to a filtered list of cars.
 */
export const findCarsByNaturalLanguage = async (query: string): Promise<Car[]> => {
  console.log('AI Service: Searching for cars with query:', query);
  
  // Simulate network delay
  await new Promise(resolve => setTimeout(resolve, 1000));

  // Basic mock logic: filter by keywords
  const lowerCaseQuery = query.toLowerCase();
  let filteredCars = cars;

  if (lowerCaseQuery.includes('suv')) {
    filteredCars = filteredCars.filter(car => car.type === 'SUV');
  }
  if (lowerCaseQuery.includes('sedan')) {
    filteredCars = filteredCars.filter(car => car.type === 'Sedan');
  }
  if (lowerCaseQuery.includes('honda')) {
    filteredCars = filteredCars.filter(car => car.make === 'Honda');
  }
  if (lowerCaseQuery.includes('toyota')) {
    filteredCars = filteredCars.filter(car => car.make === 'Toyota');
  }

  const priceMatch = lowerCaseQuery.match(/\$(\d+)/);
  if (priceMatch && priceMatch[1]) {
    const price = parseInt(priceMatch[1], 10);
    filteredCars = filteredCars.filter(car => car.price <= price);
  }

  console.log('AI Service: Found cars:', filteredCars);
  return filteredCars;
};

/**
 * Simulates generating a smart maintenance forecast for a vehicle.
 * @param car - The car object.
 * @returns A promise that resolves to a list of maintenance predictions.
 */
export const getMaintenanceForecast = async (car: Car): Promise<string[]> => {
    console.log('AI Service: Generating maintenance forecast for:', car.name);
    await new Promise(resolve => setTimeout(resolve, 500));
    
    // Mock predictions based on mileage
    const predictions = [
        "Oil change recommended in ~3,000 miles.",
        "Tire rotation due in ~5,000 miles."
    ];
    if (car.mileage > 80000 && !car.name.includes("Timing Belt Replaced")) {
        predictions.push("Timing belt typically replaced around 100k miles. Check service history.");
    }
    if (car.mileage > 50000) {
        predictions.push("Brake pads may need inspection soon.");
    }

    return predictions;
};

/**
 * Simulates an AI comparing two cars and providing a summary.
 * @param carA - The first car to compare.
 * @param carB - The second car to compare.
 * @returns A promise that resolves to a comparison summary string.
 */
export const compareCars = async (carA: Car, carB: Car): Promise<string> => {
    console.log('AI Service: Comparing', carA.name, 'and', carB.name);
    await new Promise(resolve => setTimeout(resolve, 800));

    let summary = `The ${carA.name} is a reliable ${carA.type} while the ${carB.name} is a versatile ${carB.type}. `;
    if (carA.price < carB.price) {
        summary += `The ${carA.make} is more budget-friendly. `;
    } else {
        summary += `The ${carB.make} is priced higher but may offer more features. `;
    }
    if (carA.reliabilityScore > carB.reliabilityScore) {
        summary += `Based on historical data, the ${carA.make} has a better reliability score.`;
    } else {
        summary += `The ${carB.make} boasts a slightly higher reliability score in its class.`;
    }
    return summary;
};