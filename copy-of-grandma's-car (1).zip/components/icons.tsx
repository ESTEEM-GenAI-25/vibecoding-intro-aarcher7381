
import React from 'react';

export const SparklesIcon: React.FC<{ className?: string }> = ({ className }) => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" className={className}>
    <path fillRule="evenodd" d="M10 2.5a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 2.5zM5.136 6.864a.75.75 0 011.06 0l2.475 2.475a.75.75 0 01-1.06 1.06L5.136 7.924a.75.75 0 010-1.06zM14.864 6.864a.75.75 0 010 1.06l-2.475 2.475a.75.75 0 01-1.06-1.06l2.475-2.475a.75.75 0 011.06 0zM10 10a.75.75 0 01.75.75v3.5a.75.75 0 01-1.5 0v-3.5A.75.75 0 0110 10zM3.25 10a.75.75 0 01.75-.75h3.5a.75.75 0 010 1.5h-3.5a.75.75 0 01-.75-.75zM12.5 10a.75.75 0 01.75-.75h3.5a.75.75 0 010 1.5h-3.5a.75.75 0 01-.75-.75zM5.136 13.136a.75.75 0 011.06 0l2.475-2.475a.75.75 0 011.06 1.06L6.196 14.196a.75.75 0 01-1.06-1.06zM14.864 13.136a.75.75 0 010 1.06l-2.475-2.475a.75.75 0 01-1.06-1.06l2.475 2.475a.75.75 0 011.06 0z" clipRule="evenodd" />
  </svg>
);

export const ShieldCheckIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75L11.25 15 15 9.75m-3-7.036A11.959 11.959 0 013.598 6 11.99 11.99 0 003 9.749c0 5.592 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.31-.21-2.571-.598-3.751h-.152c-3.196 0-6.1-1.248-8.25-3.286zm0 13.036h.008v.008h-.008v-.008z" />
    </svg>
);

export const WrenchScrewdriverIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.42 15.17L17.25 21A2.652 2.652 0 0021 17.25l-5.877-5.877M11.42 15.17l2.475-2.475a1.125 1.125 0 011.591 0l3.687 3.687a1.125 1.125 0 010 1.591l-2.475 2.475M11.42 15.17L5.636 20.954a1.125 1.125 0 01-1.591 0L2.475 19.389a1.125 1.125 0 010-1.591l5.877-5.877m5.877-5.877L11.42 15.17" />
    </svg>
);

export const StarIcon: React.FC<{ className?: string; solid?: boolean }> = ({ className, solid }) => (
    <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill={solid ? "currentColor" : "none"} stroke="currentColor" strokeWidth={1.5} className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.321h5.366c.529 0 .742.686.361 1.016l-4.328 3.138a.563.563 0 00-.176.623l1.598 4.804a.562.562 0 01-.812.622l-4.328-3.138a.563.563 0 00-.652 0l-4.328 3.138a.562.562 0 01-.812-.622l1.598-4.804a.563.563 0 00-.176-.623L2.53 9.947c-.381-.33-.168-1.016.361-1.016h5.366a.563.563 0 00.475-.321L11.48 3.5z" />
    </svg>
);

export const MapPinIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M15 10.5a3 3 0 11-6 0 3 3 0 016 0z" />
        <path strokeLinecap="round" strokeLinejoin="round" d="M19.5 10.5c0 7.142-7.5 11.25-7.5 11.25S4.5 17.642 4.5 10.5a7.5 7.5 0 1115 0z" />
    </svg>
);

export const ChatBubbleLeftRightIcon: React.FC<{ className?: string }> = ({ className }) => (
    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className={className}>
        <path strokeLinecap="round" strokeLinejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-3.72 3.72a1.05 1.05 0 01-1.485 0l-3.72-3.72a2.121 2.121 0 01-1.485-.618c-.377-.377-.618-.88-.618-1.422V12.71c0-1.136.847-2.1 1.98-2.193l3.72-3.72a1.05 1.05 0 011.485 0l3.72 3.72zM3.75 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193l-3.72 3.72a1.05 1.05 0 01-1.485 0l-3.72-3.72A2.121 2.121 0 01.382 18.08c-.377-.377-.618-.88-.618-1.422V12.71c0-1.136.847-2.1 1.98-2.193l3.72-3.72a1.05 1.05 0 011.485 0l3.72 3.72z" />
    </svg>
);
